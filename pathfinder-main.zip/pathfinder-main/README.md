# pathfinder

easy to use

you can see the source code and use some of it in your own project

its just a pathfinder


you can highlight two points blue one is the starting point and orange is finishing point.
you can make the way harder by drawing some lines using right click.
start the procces by pressing space.
the best path will be highlighted with color purple.
